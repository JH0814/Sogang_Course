#define _CRT_SECURE_NO_WARNINGS

#include "Camera.h"
#define TO_RADIAN 0.01745329252f  
#define TO_DEGREE 57.295779513f

int cam_chan_top = 0;// �ٸ� ī�޶� 3���� ��ȯ
int cam_chan_cc = 0;// cctv 3���� ��ȯ
glm::vec3 pos = glm::vec3(-600.0f, -600.0f, 400.0f);
// main camera ��ġ ��ȭ��
float main_u = 0.0f;
float main_v = 0.0f;
float main_n = 0.0f;
float main_fovy = 15.0f;// main camera zoom in/out
// main camera ȸ�� ����
float angle_u = 0.0f;
float angle_v = 0.0f;
float angle_n = 0.0f;
float cc_mov_fovy = 40.0f;// ���� CCTV zoom in/out
// ���� CCTV ���� ���� ����
float cc_mov_fx = 0.0f; // �¿�
float cc_mov_fy = 0.0f; // ����
float cc_mov_fz = 0.0f; // ����̱�

void Perspective_Camera::define_camera(int win_width, int win_height, float win_aspect_ratio) {
	glm::mat3 R33_t;
	glm::mat4 T;
	glm::mat3 R_u, R_v, R_n, R_total;
	glm::mat4 R;

	switch (camera_id) {
	case CAMERA_MAIN:
		flag_valid = true;
		flag_move = true; // yes. the main camera is permitted to move

		// let's use glm funtions to set up the initial camera pose
		ViewMatrix = glm::lookAt(glm::vec3(-600.0f, -600.0f, 400.0f), glm::vec3(125.0f, 80.0f, 25.0f),
			glm::vec3(0.0f, 0.0f, 1.0f)); // initial pose for main camera
		cam_view.uaxis = glm::vec3(ViewMatrix[0][0], ViewMatrix[1][0], ViewMatrix[2][0]);
		cam_view.vaxis = glm::vec3(ViewMatrix[0][1], ViewMatrix[1][1], ViewMatrix[2][1]);
		cam_view.naxis = glm::vec3(ViewMatrix[0][2], ViewMatrix[1][2], ViewMatrix[2][2]);

		R_u = glm::mat3(glm::rotate(glm::mat4(1.0f), angle_u * TO_RADIAN, cam_view.uaxis));
		R_v = glm::mat3(glm::rotate(glm::mat4(1.0f), angle_v * TO_RADIAN, cam_view.vaxis));
		R_n = glm::mat3(glm::rotate(glm::mat4(1.0f), angle_n * TO_RADIAN, cam_view.naxis));

		R_total = R_n * R_v * R_u;
		cam_view.uaxis = R_total * cam_view.uaxis;
		cam_view.vaxis = R_total * cam_view.vaxis;
		cam_view.naxis = R_total * cam_view.naxis;
		R = glm::mat4(1.0f);
		R[0][0] = cam_view.uaxis.x; R[1][0] = cam_view.uaxis.y; R[2][0] = cam_view.uaxis.z; R[3][0] = 0.0f;
		R[0][1] = cam_view.vaxis.x; R[1][1] = cam_view.vaxis.y; R[2][1] = cam_view.vaxis.z; R[3][1] = 0.0f;
		R[0][2] = cam_view.naxis.x; R[1][2] = cam_view.naxis.y; R[2][2] = cam_view.naxis.z; R[3][2] = 0.0f;
		R[0][3] = 0.0f;             R[1][3] = 0.0f;             R[2][3] = 0.0f;             R[3][3] = 1.0f;

		pos = glm::vec3(-600.0f, -600.0f, 400.0f);
		pos += main_u * cam_view.uaxis;
		pos += main_v * cam_view.vaxis;
		pos += main_n * cam_view.naxis;
		T = glm::translate(glm::mat4(1.0f), -1.0f * pos);
		ViewMatrix = R * T;
		R33_t = glm::transpose(glm::mat3(ViewMatrix));
		T = glm::mat4(R33_t) * ViewMatrix;
		cam_view.pos = -glm::vec3(T[3][0], T[3][1], T[3][2]); // why does this work?

		cam_proj.projection_type = CAMERA_PROJECTION_PERSPECTIVE;
		cam_proj.params.pers.fovy = main_fovy * TO_RADIAN;
		cam_proj.params.pers.aspect = win_aspect_ratio;  
		cam_proj.params.pers.n = 1.0f;
		cam_proj.params.pers.f = 50000.0f;

		ProjectionMatrix = glm::perspective(cam_proj.params.pers.fovy, cam_proj.params.pers.aspect,
			cam_proj.params.pers.n, cam_proj.params.pers.f);
		view_port.x = 200; view_port.y = 200; view_port.w = win_width - 200; view_port.h = win_height - 200;
		break;
	case CAMERA_SIDE_FRONT:
		if (cam_chan_top == 0) {
			flag_valid = true;
		}
		else {
			flag_valid = false;
		}
		flag_move = true; // yes. the main camera is permitted to move

		// let's use glm funtions to set up the initial camera pose
		ViewMatrix = glm::lookAt(glm::vec3(-1000.0f, 0.0f, 0.0f), glm::vec3(1.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, 1.0f)); // initial pose for main camera
		cam_view.uaxis = glm::vec3(ViewMatrix[0][0], ViewMatrix[1][0], ViewMatrix[2][0]);
		cam_view.vaxis = glm::vec3(ViewMatrix[0][1], ViewMatrix[1][1], ViewMatrix[2][1]);
		cam_view.naxis = glm::vec3(ViewMatrix[0][2], ViewMatrix[1][2], ViewMatrix[2][2]);
		R33_t = glm::transpose(glm::mat3(ViewMatrix));
		T = glm::mat4(R33_t) * ViewMatrix;
		cam_view.pos = -glm::vec3(T[3][0], T[3][1], T[3][2]); // why does this work?

		cam_proj.projection_type = CAMERA_PROJECTION_PERSPECTIVE;
		cam_proj.params.pers.fovy = 15.0f * TO_RADIAN;
		cam_proj.params.pers.aspect = win_aspect_ratio;
		cam_proj.params.pers.n = 1.0f;
		cam_proj.params.pers.f = 50000.0f;

		ProjectionMatrix = glm::ortho(-250.0f, 0.0f, 0.0f, 300.0f,
			cam_proj.params.pers.n, cam_proj.params.pers.f);
		view_port.x = -75; view_port.y = win_height - 400; view_port.w = 300; view_port.h = 400;
		break;
	case CAMERA_TOP:
		if (cam_chan_top == 1) {
			flag_valid = true;
		}
		else {
			flag_valid = false;
		}
		flag_move = true; // yes. the main camera is permitted to move

		// let's use glm funtions to set up the initial camera pose
		ViewMatrix = glm::lookAt(glm::vec3(0.0f, 0.0f, 1500.0f), glm::vec3(0.0f, 0.0f, -1.0f),
			glm::vec3(0.0f, 1.0f, 0.0f)); // initial pose for main camera
		cam_view.uaxis = glm::vec3(ViewMatrix[0][0], ViewMatrix[1][0], ViewMatrix[2][0]);
		cam_view.vaxis = glm::vec3(ViewMatrix[0][1], ViewMatrix[1][1], ViewMatrix[2][1]);
		cam_view.naxis = glm::vec3(ViewMatrix[0][2], ViewMatrix[1][2], ViewMatrix[2][2]);
		R33_t = glm::transpose(glm::mat3(ViewMatrix));
		T = glm::mat4(R33_t) * ViewMatrix;
		cam_view.pos = -glm::vec3(T[3][0], T[3][1], T[3][2]); // why does this work?

		cam_proj.projection_type = CAMERA_PROJECTION_PERSPECTIVE;
		cam_proj.params.pers.fovy = 15.0f * TO_RADIAN;
		cam_proj.params.pers.aspect = win_aspect_ratio;
		cam_proj.params.pers.n = 1.0f;
		cam_proj.params.pers.f = 50000.0f;

		ProjectionMatrix = glm::ortho(0.0f, 250.0f, 0.0f, 200.0f,
			cam_proj.params.pers.n, cam_proj.params.pers.f);
		view_port.x = 20; view_port.y = win_height - 450; view_port.w = 200; view_port.h = 200;
		break;
	case CAMERA_SIDE:
		if (cam_chan_top == 2) {
			flag_valid = true;
		}
		else {
			flag_valid = false;
		}
		flag_move = true; // yes. the main camera is permitted to move

		// let's use glm funtions to set up the initial camera pose
		ViewMatrix = glm::lookAt(glm::vec3(0.0f, -1000.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, 1.0f)); // initial pose for main camera
		cam_view.uaxis = glm::vec3(ViewMatrix[0][0], ViewMatrix[1][0], ViewMatrix[2][0]);
		cam_view.vaxis = glm::vec3(ViewMatrix[0][1], ViewMatrix[1][1], ViewMatrix[2][1]);
		cam_view.naxis = glm::vec3(ViewMatrix[0][2], ViewMatrix[1][2], ViewMatrix[2][2]);
		R33_t = glm::transpose(glm::mat3(ViewMatrix));
		T = glm::mat4(R33_t) * ViewMatrix;
		cam_view.pos = -glm::vec3(T[3][0], T[3][1], T[3][2]); // why does this work?

		cam_proj.projection_type = CAMERA_PROJECTION_PERSPECTIVE;
		cam_proj.params.pers.fovy = 15.0f * TO_RADIAN;
		cam_proj.params.pers.aspect = win_aspect_ratio;
		cam_proj.params.pers.n = 1.0f;
		cam_proj.params.pers.f = 50000.0f;

		ProjectionMatrix = glm::ortho(0.0f, 250.0f, 0.0f, 200.0f,
			cam_proj.params.pers.n, cam_proj.params.pers.f);
		view_port.x = 0; view_port.y = win_height - 400; view_port.w = 300; view_port.h = 300;
		break;
	case CAMERA_CC_0:
		if (cam_chan_cc == 0) {
			flag_valid = true;
		}
		else {
			flag_valid = false;
		}
		flag_move = true; // yes. the main camera is permitted to move

		// let's use glm funtions to set up the initial camera pose
		ViewMatrix = glm::lookAt(glm::vec3(10.0f, 160.0f, 50.0f), glm::vec3(125.0f, 120.0f, 10.0f),
			glm::vec3(0.0f, 0.0f, 1.0f)); // initial pose for main camera
		cam_view.uaxis = glm::vec3(ViewMatrix[0][0], ViewMatrix[1][0], ViewMatrix[2][0]);
		cam_view.vaxis = glm::vec3(ViewMatrix[0][1], ViewMatrix[1][1], ViewMatrix[2][1]);
		cam_view.naxis = glm::vec3(ViewMatrix[0][2], ViewMatrix[1][2], ViewMatrix[2][2]);
		R33_t = glm::transpose(glm::mat3(ViewMatrix));
		T = glm::mat4(R33_t) * ViewMatrix;
		cam_view.pos = -glm::vec3(T[3][0], T[3][1], T[3][2]); // why does this work?

		cam_proj.projection_type = CAMERA_PROJECTION_PERSPECTIVE;
		cam_proj.params.pers.fovy = 30.0f * TO_RADIAN;
		cam_proj.params.pers.aspect = win_aspect_ratio;
		cam_proj.params.pers.n = 1.0f;
		cam_proj.params.pers.f = 50000.0f;

		ProjectionMatrix = glm::perspective(cam_proj.params.pers.fovy, cam_proj.params.pers.aspect,
			cam_proj.params.pers.n, cam_proj.params.pers.f);
		view_port.x = 0; view_port.y = win_height - 250; view_port.w = 200; view_port.h = 250;
		break;
	case CAMERA_CC_1:
		if (cam_chan_cc == 1) {
			flag_valid = true;
		}
		else {
			flag_valid = false;
		}
		flag_move = true; // yes. the main camera is permitted to move

		// let's use glm funtions to set up the initial camera pose
		ViewMatrix = glm::lookAt(glm::vec3(170.0f, 15.0f, 50.0f), glm::vec3(230.0f, 150.0f, 25.0f),
			glm::vec3(0.0f, 0.0f, 1.0f)); // initial pose for main camera
		cam_view.uaxis = glm::vec3(ViewMatrix[0][0], ViewMatrix[1][0], ViewMatrix[2][0]);
		cam_view.vaxis = glm::vec3(ViewMatrix[0][1], ViewMatrix[1][1], ViewMatrix[2][1]);
		cam_view.naxis = glm::vec3(ViewMatrix[0][2], ViewMatrix[1][2], ViewMatrix[2][2]);
		R33_t = glm::transpose(glm::mat3(ViewMatrix));
		T = glm::mat4(R33_t) * ViewMatrix;
		cam_view.pos = -glm::vec3(T[3][0], T[3][1], T[3][2]); // why does this work?

		cam_proj.projection_type = CAMERA_PROJECTION_PERSPECTIVE;
		cam_proj.params.pers.fovy = 30.0f * TO_RADIAN;
		cam_proj.params.pers.aspect = win_aspect_ratio;
		cam_proj.params.pers.n = 1.0f;
		cam_proj.params.pers.f = 50000.0f;

		ProjectionMatrix = glm::perspective(cam_proj.params.pers.fovy, cam_proj.params.pers.aspect,
			cam_proj.params.pers.n, cam_proj.params.pers.f);
		view_port.x = 0; view_port.y = win_height - 250; view_port.w = 200; view_port.h = 250;
		break;
	case CAMERA_CC_2:
		if (cam_chan_cc == 2) {
			flag_valid = true;
		}
		else {
			flag_valid = false;
		}
		flag_move = true; // yes. the main camera is permitted to move

		// let's use glm funtions to set up the initial camera pose
		ViewMatrix = glm::lookAt(glm::vec3(95.0f, 15.0f, 50.0f), glm::vec3(70.0f, 80.0f, 25.0f),
			glm::vec3(0.0f, 0.0f, 1.0f)); // initial pose for main camera
		cam_view.uaxis = glm::vec3(ViewMatrix[0][0], ViewMatrix[1][0], ViewMatrix[2][0]);
		cam_view.vaxis = glm::vec3(ViewMatrix[0][1], ViewMatrix[1][1], ViewMatrix[2][1]);
		cam_view.naxis = glm::vec3(ViewMatrix[0][2], ViewMatrix[1][2], ViewMatrix[2][2]);
		R33_t = glm::transpose(glm::mat3(ViewMatrix));
		T = glm::mat4(R33_t) * ViewMatrix;
		cam_view.pos = -glm::vec3(T[3][0], T[3][1], T[3][2]); // why does this work?

		cam_proj.projection_type = CAMERA_PROJECTION_PERSPECTIVE;
		cam_proj.params.pers.fovy = 40.0f * TO_RADIAN;
		cam_proj.params.pers.aspect = win_aspect_ratio;
		cam_proj.params.pers.n = 1.0f;
		cam_proj.params.pers.f = 50000.0f;

		ProjectionMatrix = glm::perspective(cam_proj.params.pers.fovy, cam_proj.params.pers.aspect,
			cam_proj.params.pers.n, cam_proj.params.pers.f);
		view_port.x = 0; view_port.y = win_height - 250; view_port.w = 200; view_port.h = 250;
		break;
	case CAMERA_CC_MOV:
		flag_valid = true;
		flag_move = true; // yes. the main camera is permitted to move

		// let's use glm funtions to set up the initial camera pose
		ViewMatrix = glm::lookAt(glm::vec3(150.0f, 120.0f, 50.0f), glm::vec3(180.0f, 150.0f, 25.0f),
			glm::vec3(0.0f, 0.0f, 1.0f)); // initial pose for main camera
		cam_view.uaxis = glm::vec3(ViewMatrix[0][0], ViewMatrix[1][0], ViewMatrix[2][0]);
		cam_view.vaxis = glm::vec3(ViewMatrix[0][1], ViewMatrix[1][1], ViewMatrix[2][1]);
		cam_view.naxis = glm::vec3(ViewMatrix[0][2], ViewMatrix[1][2], ViewMatrix[2][2]);

		glm::vec3 naxis_proj_xy = glm::normalize(glm::vec3(cam_view.naxis.x, cam_view.naxis.y, 0.0f));
		glm::vec3 pitch_axis = glm::cross(naxis_proj_xy, glm::vec3(0.0f, 0.0f, 1.0f));
		pitch_axis = glm::normalize(pitch_axis);
		R_u = glm::mat3(glm::rotate(glm::mat4(1.0f), cc_mov_fx * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f)));
		R_v = glm::mat3(glm::rotate(glm::mat4(1.0f), cc_mov_fy * TO_RADIAN, pitch_axis));
		R_n = glm::mat3(glm::rotate(glm::mat4(1.0f), cc_mov_fz * TO_RADIAN, cam_view.naxis));

		R_total = R_u * R_v * R_n;
		cam_view.uaxis = R_total * cam_view.uaxis;
		cam_view.vaxis = R_total * cam_view.vaxis;
		cam_view.naxis = R_total * cam_view.naxis;
		R = glm::mat4(1.0f);
		R[0][0] = cam_view.uaxis.x; R[1][0] = cam_view.uaxis.y; R[2][0] = cam_view.uaxis.z; R[3][0] = 0.0f;
		R[0][1] = cam_view.vaxis.x; R[1][1] = cam_view.vaxis.y; R[2][1] = cam_view.vaxis.z; R[3][1] = 0.0f;
		R[0][2] = cam_view.naxis.x; R[1][2] = cam_view.naxis.y; R[2][2] = cam_view.naxis.z; R[3][2] = 0.0f;
		R[0][3] = 0.0f;             R[1][3] = 0.0f;             R[2][3] = 0.0f;             R[3][3] = 1.0f;

		T = glm::translate(glm::mat4(1.0f), -1.0f * glm::vec3(150.0f, 120.0f, 50.0f));
		ViewMatrix = R * T;
		R33_t = glm::transpose(glm::mat3(ViewMatrix));
		T = glm::mat4(R33_t) * ViewMatrix;
		cam_view.pos = -glm::vec3(T[3][0], T[3][1], T[3][2]); // why does this work?

		cam_proj.projection_type = CAMERA_PROJECTION_PERSPECTIVE;
		cam_proj.params.pers.fovy = cc_mov_fovy * TO_RADIAN;
		cam_proj.params.pers.aspect = win_aspect_ratio;
		cam_proj.params.pers.n = 1.0f;
		cam_proj.params.pers.f = 50000.0f;

		ProjectionMatrix = glm::perspective(cam_proj.params.pers.fovy, cam_proj.params.pers.aspect,
			cam_proj.params.pers.n, cam_proj.params.pers.f);
		view_port.x = 0; view_port.y = 50; view_port.w = 200; view_port.h = 250;
		break;
	}
}

