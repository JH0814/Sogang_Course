#define _CRT_SECURE_NO_WARNINGS

#include "Scene_Definitions.h"


float spider_prev_x, spider_prev_y;

void Tiger_D::define_object() {
#define N_TIGER_FRAMES 12
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_TIGER_FRAMES; i++) {
		object_frames.emplace_back();
		sprintf(object_frames[i].filename, "Data/Tiger_%d%d_triangles_vnt.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		cur_MM = &(object_frames[i].instances.back().ModelMatrix);
		*cur_MM = glm::scale(glm::mat4(1.0f), glm::vec3(0.2f, 0.2f, 0.2f));
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->ambient = glm::vec4(0.329412f, 0.223529f, 0.027451f, 1.0f);
		cur_material->diffuse = glm::vec4(0.780392f, 0.568627f, 0.113725f, 1.0f);
		cur_material->specular = glm::vec4(0.992157f, 0.941176f, 0.807843f, 1.0f);
		cur_material->exponent = 128.0f * 0.21794872f;
	}
}

void Cow_D::define_object() {
#define N_FRAMES_COW_1 1
#define N_FRAMES_COW_2 1
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;
	switch (object_id) {

		int n_frames;
	case DYNAMIC_OBJECT_COW_1:
		n_frames = N_FRAMES_COW_1;
		for (int i = 0; i < n_frames; i++) {
			object_frames.emplace_back();
			strcpy(object_frames[i].filename, "Data/cow_vn.geom");
			object_frames[i].n_fields = 6;
			object_frames[i].front_face_mode = GL_CCW;
			object_frames[i].prepare_geom_of_static_object();
			object_frames[i].instances.emplace_back();
			cur_MM = &(object_frames[i].instances.back().ModelMatrix);
			*cur_MM = glm::scale(glm::mat4(1.0f), glm::vec3(30.0f, 30.0f, 30.0f));
			cur_material = &(object_frames[i].instances.back().material);
			cur_material->emission = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
			cur_material->ambient = glm::vec4(0.329412f, 0.223529f, 0.027451f, 1.0f);
			cur_material->diffuse = glm::vec4(0.780392f, 0.568627f, 0.113725f, 1.0f);
			cur_material->specular = glm::vec4(0.992157f, 0.941176f, 0.807843f, 1.0f);
			cur_material->exponent = 128.0f * 0.21794872f;
		}
		break;
	case DYNAMIC_OBJECT_COW_2:
		n_frames = N_FRAMES_COW_2;
		for (int i = 0; i < n_frames; i++) {
			object_frames.emplace_back();
			strcpy(object_frames[i].filename, "Data/cow_vn.geom");
			object_frames[i].n_fields = 6;
			object_frames[i].front_face_mode = GL_CCW;
			object_frames[i].prepare_geom_of_static_object();

			object_frames[i].instances.emplace_back();
			cur_MM = &(object_frames[i].instances.back().ModelMatrix);
			*cur_MM = glm::scale(glm::mat4(1.0f), glm::vec3(30.0f, 30.0f, 30.0f));
			cur_material = &(object_frames[i].instances.back().material);
			glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
			cur_material->ambient = glm::vec4(0.25f, 0.25f, 0.25f, 1.0f);
			cur_material->diffuse = glm::vec4(0.4f, 0.4f, 0.4f, 1.0f);
			cur_material->specular = glm::vec4(0.774597f, 0.774597f, 0.774597f, 1.0f);
			cur_material->exponent = 128.0f * 0.6f;
		}
		break;
	}
}

// �߰��� dynamic object
void Spider_D::define_object() {
#define N_SPIDER_FRAMES 16
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_SPIDER_FRAMES; i++) {
		object_frames.emplace_back();
		sprintf(object_frames[i].filename, "Data/dynamic_objects/spider/spider_vnt_%d%d.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		cur_MM = &(object_frames[i].instances.back().ModelMatrix);
		*cur_MM = glm::scale(glm::mat4(1.0f), glm::vec3(8.0f, 8.0f, 8.0f));
		*cur_MM = glm::rotate(*cur_MM, -90.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		*cur_MM = glm::rotate(*cur_MM, -90.0f * TO_RADIAN, glm::vec3(1.0f, 0.0f, 0.0f));
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->ambient = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f);
		cur_material->diffuse = glm::vec4(0.9f, 0.5f, 0.1f, 1.0f);
		cur_material->specular = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f);
		cur_material->exponent = 11.334717f;
	}
}
void Ben_D::define_object() {
#define N_BEN_FRAMES 30
	glm::mat4* cur_MM;
	Material* cur_material;
	flag_valid = true;

	for (int i = 0; i < N_BEN_FRAMES; i++) {
		object_frames.emplace_back();
		sprintf(object_frames[i].filename, "Data/dynamic_objects/ben/ben_vntm_%d%d.geom", i / 10, i % 10);
		object_frames[i].n_fields = 8;
		object_frames[i].front_face_mode = GL_CW;
		object_frames[i].prepare_geom_of_static_object();

		object_frames[i].instances.emplace_back();
		cur_MM = &(object_frames[i].instances.back().ModelMatrix);
		*cur_MM = glm::scale(glm::mat4(1.0f), glm::vec3(25.0f, 25.0f, 25.0f));
		*cur_MM = glm::rotate(*cur_MM, -90.0f * TO_RADIAN, glm::vec3(1.0f, 0.0f, 0.0f));
		//*cur_MM = glm::rotate(*cur_MM, -90.0f * TO_RADIAN, glm::vec3(1.0f, 0.0f, 0.0f));
		cur_material = &(object_frames[i].instances.back().material);
		cur_material->emission = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
		cur_material->ambient = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f);
		cur_material->diffuse = glm::vec4(0.9f, 0.5f, 0.1f, 1.0f);
		cur_material->specular = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f);
		cur_material->exponent = 11.334717f;
	}
}

void Dynamic_Object::draw_object(glm::mat4& ViewMatrix, glm::mat4& ProjectionMatrix, SHADER_ID shader_kind,
	std::vector<std::reference_wrapper<Shader>>& shader_list, int time_stamp) {
	int cur_object_index = time_stamp % object_frames.size();
	Static_Object& cur_object = object_frames[cur_object_index];
	glFrontFace(cur_object.front_face_mode);

	float rotation_angle = 0.0f;
	float spider_x, spider_y, spider_roc_time, ben_roc_time;
	glm::mat4 ModelMatrix = glm::mat4(1.0f);
	switch (object_id) {
	case DYNAMIC_OBJECT_TIGER:
		rotation_angle = (time_stamp % 360) * TO_RADIAN;
		ModelMatrix = glm::rotate(ModelMatrix, -rotation_angle, glm::vec3(0.0f, 0.0f, 1.0f));
		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(100.0f, 0.0f, 0.0f));
		break;
	case DYNAMIC_OBJECT_COW_1:
		rotation_angle = (2 * time_stamp % 360) * TO_RADIAN;
		ModelMatrix = glm::rotate(ModelMatrix, -rotation_angle, glm::vec3(0.0f, 0.0f, 1.0f));
		break;
	case DYNAMIC_OBJECT_COW_2:
		rotation_angle = (5 * time_stamp % 360) * TO_RADIAN;
		ModelMatrix = glm::translate(ModelMatrix, glm::vec3(100.0f, 50.0f, 0.0f));
		ModelMatrix = glm::rotate(ModelMatrix, rotation_angle, glm::vec3(1.0f, 0.0f, 0.0f));
		break;
	case DYNAMIC_OBJECT_SPIDER:
		spider_roc_time = time_stamp % 380; // 80 ~ 150������ ����, ��ȸ���ߴٰ� ������ ��� ���ƿ��� ��Ʈ
		if (spider_roc_time >= 310) {
			spider_x = 460.0f - spider_roc_time;
			spider_y = 100.0f;
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(spider_x, spider_y, 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 180.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if ((spider_roc_time >= 70.0f && spider_roc_time <= 160.0f)) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(150.0f + 20.0f * cos((spider_roc_time - 160.0f) * TO_RADIAN), 120.0f + 20.0f * sin((spider_roc_time - 160.0f) * TO_RADIAN), 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, (spider_roc_time - 70.0f) * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (spider_roc_time > 160.0f && spider_roc_time <= 190.0f) {
			spider_x = 170.0f;
			spider_y = spider_roc_time - 40.0f;
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(spider_x, spider_y, 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 90.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (spider_roc_time > 190.0f && spider_roc_time < 220.0f) {
			spider_x = 170.0f;
			spider_y = 340.0f - spider_roc_time;
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(spider_x, spider_y, 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, -90.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if ((spider_roc_time >= 220.0f && spider_roc_time < 310.0f)) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(150.0f + 20.0f * cos(-1.0f * (spider_roc_time - 220.0f) * TO_RADIAN), 120.0f + 20.0f * sin(-1.0f * (spider_roc_time - 220.0f) * TO_RADIAN), 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, -1.0f * (spider_roc_time - 130.0f) * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else {
			spider_x = spider_roc_time + 80.0f;
			spider_y = 100.0f;
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(spider_x, spider_y, 0.0f));
		}
		break;
	case DYNAMIC_OBJECT_BEN:
		ben_roc_time = time_stamp % 340;
		if (ben_roc_time <= 10) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(45.0f, 40.0f - ben_roc_time, 0.0f));
		}
		else if (ben_roc_time <= 40) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(55.0f + 10.0f * cos((3.0f * (ben_roc_time - 10.0f) + 180.0f) * TO_RADIAN), 30.0f + 10.0f * sin((3.0f * (ben_roc_time - 10.0f) + 180.0f) * TO_RADIAN), 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, (3.0f * (ben_roc_time - 10.0f) + 180.0f) * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 180.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 45) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(ben_roc_time + 15.0f, 20.0f, 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 90.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 75) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(60.0f + 10.0f * cos((3.0f * (ben_roc_time - 45.0f) - 90.0f) * TO_RADIAN), 30.0f + 10.0f * sin((3.0f * (ben_roc_time - 45.0f) - 90.0f) * TO_RADIAN), 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, (3.0f * (ben_roc_time - 45.0f) - 90.0f) * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 180.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 110) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(70.0f, ben_roc_time - 45.0f, 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 180.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 140) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(60.0f + 10.0f * cos((3.0f * (ben_roc_time - 110.0f)) * TO_RADIAN), 65.0f + 10.0f * sin((3.0f * (ben_roc_time - 110.0f)) * TO_RADIAN), 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, (3.0f * (ben_roc_time - 110.0f)) * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 180.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 170) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(200.0f - ben_roc_time, 75.0f, 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 270.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 200) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(ben_roc_time - 140.0f, 75.0f, 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 90.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 230) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(60.0f + 10.0f * cos((-3.0f * (ben_roc_time - 200.0f) + 90.0f) * TO_RADIAN), 65.0f + 10.0f * sin((-3.0f * (ben_roc_time - 200.0f) + 90.0f) * TO_RADIAN), 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, (-3.0f * (ben_roc_time - 200.0f) + 90.0f) * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 265) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(70.0f, 295.0f - ben_roc_time, 0.0f));
		}
		else if (ben_roc_time <= 295) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(60.0f + 10.0f * cos((-3.0f * (ben_roc_time - 265.0f)) * TO_RADIAN), 30.0f + 10.0f * sin((-3.0f * (ben_roc_time - 265.0f)) * TO_RADIAN), 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, (-3.0f * (ben_roc_time - 265.0f)) * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 300) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(355.0f - ben_roc_time, 20.0f, 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 270.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 330) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(55.0f + 10.0f * cos((-3.0f * (ben_roc_time - 300.0f) - 90.0f) * TO_RADIAN), 30.0f + 10.0f * sin((-3.0f * (ben_roc_time - 300.0f) - 90.0f) * TO_RADIAN), 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, (-3.0f * (ben_roc_time - 300.0f) - 90.0f) * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		else if (ben_roc_time <= 340) {
			ModelMatrix = glm::translate(ModelMatrix, glm::vec3(45.0f, ben_roc_time - 300.0f, 0.0f));
			ModelMatrix = glm::rotate(ModelMatrix, 180.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
		}
		break;
	}

	for (int i = 0; i < cur_object.instances.size(); i++) {
		glm::mat4 ModelViewProjectionMatrix = ProjectionMatrix * ViewMatrix * ModelMatrix * cur_object.instances[i].ModelMatrix;
		switch (shader_kind) {
		case SHADER_SIMPLE:
			Shader_Simple* shader_simple_ptr = static_cast<Shader_Simple*>(&shader_list[shader_ID_mapper[shader_kind]].get());
			glUseProgram(shader_simple_ptr->h_ShaderProgram);
			glUniformMatrix4fv(shader_simple_ptr->loc_ModelViewProjectionMatrix, 1, GL_FALSE,
				&ModelViewProjectionMatrix[0][0]);
			glUniform3f(shader_simple_ptr->loc_primitive_color, cur_object.instances[i].material.diffuse.r,
				cur_object.instances[i].material.diffuse.g, cur_object.instances[i].material.diffuse.b);
			break;
		}
		glBindVertexArray(cur_object.VAO);
		glDrawArrays(GL_TRIANGLES, 0, 3 * cur_object.n_triangles);
		glBindVertexArray(0);
		glUseProgram(0);
	}
}