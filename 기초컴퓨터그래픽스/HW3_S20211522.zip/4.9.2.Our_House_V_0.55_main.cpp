#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include "Shaders/LoadShaders.h"
#include "Scene_Definitions.h"

Scene scene;

void display(void) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	for (auto camera = scene.camera_list.begin(); camera != scene.camera_list.end(); camera++) {
		if (camera->get().flag_valid == false) continue;
		glViewport(camera->get().view_port.x, camera->get().view_port.y,
			camera->get().view_port.w, camera->get().view_port.h);
		scene.ViewMatrix = camera->get().ViewMatrix;
		scene.ProjectionMatrix = camera->get().ProjectionMatrix;

		scene.draw_world();
	}
	glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y) {
	static int flag_cull_face = 0, polygon_fill_on = 0, depth_test_on = 0;

	switch (key) {
	case 27: // ESC key
		glutLeaveMainLoop(); // Incur destuction callback for cleanups.
		break;
	case 'c':
		flag_cull_face = (flag_cull_face + 1) % 3;
		switch (flag_cull_face) {
		case 0:
			glDisable(GL_CULL_FACE);
			glutPostRedisplay();
			fprintf(stdout, "^^^ No faces are culled.\n");
			break;
		case 1: // cull back faces;
			glCullFace(GL_BACK);
			glEnable(GL_CULL_FACE);
			glutPostRedisplay();
			fprintf(stdout, "^^^ Back faces are culled.\n");
			break;
		case 2: // cull front faces;
			glCullFace(GL_FRONT);
			glEnable(GL_CULL_FACE);
			glutPostRedisplay();
			fprintf(stdout, "^^^ Front faces are culled.\n");
			break;
		}
		break;
	case 'f':
		polygon_fill_on = 1 - polygon_fill_on;
		if (polygon_fill_on) {
		 	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			fprintf(stdout, "^^^ Polygon filling enabled.\n");
		}
		else {
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			fprintf(stdout, "^^^ Line drawing enabled.\n");
		}
		glutPostRedisplay();
		break;
	case 'd':
		depth_test_on = 1 - depth_test_on;
		if (depth_test_on) {
			glEnable(GL_DEPTH_TEST);
			fprintf(stdout, "^^^ Depth test enabled.\n");
		}
		else {
			glDisable(GL_DEPTH_TEST);
			fprintf(stdout, "^^^ Depth test disabled.\n");
		}
		glutPostRedisplay();
		break;
	// �߰��� Ű
	// ����, ����, ��鵵 ī�޶� ��ȯ
	case 'q':
		cam_chan_top = (cam_chan_top + 1) % 3;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	// ���� CCTV 3���� ī�޶� ��ȯ
	case 'e':
		cam_chan_cc = (cam_chan_cc + 1) % 3;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	// main camera ��ġ �̵�
	case 'i':
		main_v += 2.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case 'k':
		main_v += -2.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case 'j':
		main_u += -2.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case 'l':
		main_u += 2.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case 'm':
		main_n += 2.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case 'n':
		main_n += -2.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	//main camera�� �� ȸ��
	case 'o':
		angle_u += -1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case 'p':
		angle_u += 1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case '[':
		angle_v += -1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case ']':
		angle_v += 1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case ';':
		angle_n += -1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case '\'':
		angle_n += 1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	// ���� CCTV�� zoom in/out
	case 'a':
		cc_mov_fovy += 1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case 's':
		cc_mov_fovy += -1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	// ���� CCTV�� ���� ����
	case '2':
		cc_mov_fy += 1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case '8':
		cc_mov_fy += -1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case '4':
		cc_mov_fx += 1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case '6':
		cc_mov_fx += -1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case '=':
		cc_mov_fz += 1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case '-':
		cc_mov_fz += -1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case '5':
		axis_main_on = (axis_main_on + 1) % 2;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	case '0':
		axis_cc_on = (axis_cc_on + 1) % 2;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
		break;
	}
}

void mouseWheel(int button, int dir, int x, int y) {
	// main camera zoom in/out
	if (dir > 0) {
		main_fovy += -1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
	}
	else if (dir < 0) {
		main_fovy += 1.0f;
		scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
		glutPostRedisplay();
	}
}

void reshape(int width, int height) {
	scene.window.width = width;
	scene.window.height = height;
	scene.window.aspect_ratio = (float)width / height;
	scene.create_camera_list(scene.window.width, scene.window.height, scene.window.aspect_ratio);
	glutPostRedisplay();
}

void timer_scene(int index) {
	scene.clock(0);
	glutPostRedisplay();
	glutTimerFunc(100, timer_scene, 0);
}

void register_callbacks(void) {
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutMouseWheelFunc(mouseWheel);
	glutReshapeFunc(reshape);
 	glutTimerFunc(100, timer_scene, 0);
//	glutCloseFunc(cleanup_OpenGL_stuffs or else); // Do it yourself!!!
}

void initialize_OpenGL(void) {
	glEnable(GL_DEPTH_TEST); // Default state
	 
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glClearColor(0.12f, 0.18f, 0.12f, 1.0f);
}

void initialize_renderer(void) {
	register_callbacks();
	initialize_OpenGL();
	scene.initialize();
}

void initialize_glew(void) {
	GLenum error;

	glewExperimental = GL_TRUE;

	error = glewInit();
	if (error != GLEW_OK) {
		fprintf(stderr, "Error: %s\n", glewGetErrorString(error));
		exit(-1);
	}
	fprintf(stdout, "*********************************************************\n");
	fprintf(stdout, " - GLEW version supported: %s\n", glewGetString(GLEW_VERSION));
	fprintf(stdout, " - OpenGL renderer: %s\n", glGetString(GL_RENDERER));
	fprintf(stdout, " - OpenGL version supported: %s\n", glGetString(GL_VERSION));
	fprintf(stdout, "*********************************************************\n\n");
}

void print_message(const char * m) {
	fprintf(stdout, "%s\n\n", m);
}

void greetings(char *program_name, char messages[][256], int n_message_lines) {
	fprintf(stdout, "**************************************************************\n\n");
	fprintf(stdout, "  PROGRAM NAME: %s\n\n", program_name);
	fprintf(stdout, "    This program was coded for CSE4170/AIE4012 students\n");
	fprintf(stdout, "      of Dept. of Comp. Sci. & Eng., Sogang University.\n\n");

	for (int i = 0; i < n_message_lines; i++)
		fprintf(stdout, "%s\n", messages[i]);
	fprintf(stdout, "\n**************************************************************\n\n");

	initialize_glew();
}

#define N_MESSAGE_LINES 1
void main(int argc, char *argv[]) {
	char program_name[256] = "Sogang CSE4170/AIE4120 Our_House_GLSL_V_0.55";
	char messages[N_MESSAGE_LINES][256] = { "    - Keys used: \na, s:CCTV_MOV zoom out/in\nq:change camera(side_front, top, side)\ne:change CCTV\ni, k:move main_camera's pos through v\nj, l:move main_camera's pos through u\nm, n:move main_camera's pos through n\nmouse wheel:main_camera zoom in/out\n" };

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_MULTISAMPLE);
	glutInitWindowSize(1200, 800);
	glutInitContextVersion(4, 0);
	glutInitContextProfile(GLUT_CORE_PROFILE);
	glutCreateWindow(program_name);

	greetings(program_name, messages, N_MESSAGE_LINES);
	initialize_renderer();

	glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);
	glutMainLoop();
}
